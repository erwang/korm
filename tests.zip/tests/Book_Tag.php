<?php

 namespace KORM\Tests;

use KORM\Object;

class Book_Tag extends Object{
    
}