<?php

 namespace KORM\Tests;

use KORM\Object;

class Author extends Object{
    
}