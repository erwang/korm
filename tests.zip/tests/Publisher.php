<?php

 namespace KORM\Tests;

use KORM\Object;

class Publisher extends Object{
    
}