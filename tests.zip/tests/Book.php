<?php

 namespace KORM\Tests;

use KORM\Object;

class Book extends Object{
    
}