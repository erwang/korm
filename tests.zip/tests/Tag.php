<?php

 namespace KORM\Tests;

use KORM\Object;

class Tag extends Object{
    
}